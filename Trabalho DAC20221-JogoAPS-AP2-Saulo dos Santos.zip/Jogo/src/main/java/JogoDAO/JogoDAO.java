package JogoDAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import JPAUtil.JPAUtil;
import entidade.Jogo;


public class JogoDAO {
	
	public static void salvar(Jogo jogo) {
		EntityManager em = JPAUtil.criarEntityManager();// Criar um EntityManager
		em.getTransaction().begin();// Iniciar uma transa��o
		em.persist(jogo);// pegar o id da sequence e preparar o insert
		em.getTransaction().commit();// sincronizar com o BD executando o insert
		em.close();// fechar o EntityManager

	}

	public static void editar(Jogo jogo) {
		EntityManager em = JPAUtil.criarEntityManager();// Criar um EntityManager
		em.getTransaction().begin();
		em.merge(jogo);//
		em.getTransaction().commit();// sincronizar com o BD executando o insert
		em.close();// fechar o EntityManager

	}

	public static void excluir(Jogo jogo) {
		EntityManager em = JPAUtil.criarEntityManager();
		em.getTransaction().begin();
		jogo = em.find(Jogo.class, jogo.getId());
		em.remove(jogo);
		em.getTransaction().commit();
		em.close();
	}

	public static List<Jogo> listar() {
		EntityManager em = JPAUtil.criarEntityManager();
		Query q = em.createQuery("select j from Jogo j");
		List<Jogo> lista = q.getResultList();
		em.close();
		return lista;
	}


}
