package bean;
import java.util.List;
import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import JogoDAO.JogoDAO;
import entidade.Jogo;

@ManagedBean
public class JogoBean {
	
	private Jogo jogo = new Jogo();
	
	private List<Jogo>lista;
	
	public String salvar() {
		try {
			JogoDAO.salvar(jogo);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Jogo salvo com sucesso"));
			jogo = new Jogo();
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao salvar jogo"));
		}
		return "lista";
	}

	public String editar() {
		try {
			JogoDAO.editar(jogo);
			
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Jogo editado com sucesso"));
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, null, "Erro ao editar jogo"));
		}
		return "lista";
	}

	public String excluir() {	
		try {
			JogoDAO.excluir(jogo);
			lista.remove(jogo); // removendo direto da lista
			FacesContext.getCurrentInstance()
			.addMessage(null, new FacesMessage(
					FacesMessage.SEVERITY_INFO, "Sucesso", "Jogo excluido com sucesso"));
			
		} catch (Exception e) {
			
			FacesContext.getCurrentInstance()
			.addMessage(null, new FacesMessage(
					FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao excluir jogo"));
		}
		return null;
	}
	

	public Jogo getJogo() {
		return jogo;
	}

	public void setJogo(Jogo jogo) {
		this.jogo = jogo;
	}

	public List<Jogo> getLista() {
		if (lista == null) {
			lista = JogoDAO.listar();
		}
		return lista;
	}

	public void setLista(List<Jogo> lista) {
		this.lista = lista;
	}
	
}
