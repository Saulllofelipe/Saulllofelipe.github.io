package Adivinhacao;

import java.io.PrintStream;
import java.util.Random;
import java.util.Scanner;

public class Jogo {

	public static void main(String[] args) {
		
		//classe PrintStream 
		PrintStream show = System.out;
		Scanner sc = new Scanner(System.in);
		Random gerador = new Random();
		
		int opcao;
		int escolha_computador;
		int escolha_usuario;
		
		show.println("Ol�! Qual o seu nome?");
		String nome = sc.nextLine();
		show.println("Bem vindo ao jogo " + nome + "!");
		show.println(nome + ", voc� quer jogar comigo?" );
		show.println("\nDigite o n�mero da op��o.\n1 -> Sim \n2 -> N�o");
		opcao = sc.nextInt();
		
		if (opcao == 2) {
			
			show.println("Que pena! Fica para a pr�xima. Tchau!");
		} else if(opcao ==1) {
			
			show.println("Vamos l�!");
			show.println("Eu vou escolher um n�mero de 0  a 10!");
			show.println("N�o vou falar pra voc� qual o n�mero escolhi");
			show.println("Adivinhando voc� ser� o vencedor!");
			
			escolha_computador = gerador.nextInt(11);
			
			show.println("Pronto, " + nome + ". J� escolhi o n�mero!");
			show.println("Agora tente adivinhar!");
			
			do {
				escolha_usuario = sc.nextInt();
				if(escolha_usuario != escolha_computador) {
					show.println("Resposta errada! Tente de novo.");
				}else {
					show.println("Acertou miserave! Kkkkkkkk");
				}
			
			} while(escolha_computador != escolha_usuario);		
		}
		

	}

}
